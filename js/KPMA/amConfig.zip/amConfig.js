var kidozPanelEnabled = true;
console.log('kidoz panel' + kidozPanelEnabled);