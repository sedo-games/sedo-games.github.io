var kidozPanelEnabled = false;
console.log('kidoz panel' + kidozPanelEnabled);