kidozPanelEnabled = false;
console.log('kidoz panel from loaded config' + kidozPanelEnabled);